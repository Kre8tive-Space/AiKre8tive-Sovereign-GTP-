#!/bin/bash
echo '🛠️ Executing NLP2BUILD_auto.sh...'
