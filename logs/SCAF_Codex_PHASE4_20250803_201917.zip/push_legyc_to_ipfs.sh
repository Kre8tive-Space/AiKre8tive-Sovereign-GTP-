#!/bin/bash
echo '🛠️ Executing push_legyc_to_ipfs.sh...'
