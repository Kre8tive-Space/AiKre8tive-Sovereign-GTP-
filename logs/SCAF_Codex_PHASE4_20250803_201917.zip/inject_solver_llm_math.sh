#!/bin/bash
echo '🛠️ Running inject_solver_llm_math.sh...'
