#!/bin/bash
echo '🛠️ Running inject_solver_chainlit_ops.sh...'
