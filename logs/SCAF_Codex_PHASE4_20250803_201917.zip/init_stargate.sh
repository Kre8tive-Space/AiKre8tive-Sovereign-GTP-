#!/bin/bash
echo '🛠️ Executing init_stargate.sh...'
